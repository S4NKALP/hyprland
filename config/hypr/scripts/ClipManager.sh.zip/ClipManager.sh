#!/usr/bin/env bash

# Clipboard Manager. This needs cliphist & wl-copy and of course rofi
while true; do
    if ! pidof rofi >/dev/null; then
        result=$(cliphist list | rofi -dmenu -config ~/.config/rofi/config-long.rasi)
    else
        pkill rofi
    fi

    exit_state=$?
    if [[ $exit_state -eq 1 ]]; then
        exit
    fi

    case "$exit_state" in
        0)
            action=$(echo -e "Copy\nDelete\nDelete All\nExit" | rofi -dmenu -config ~/.config/rofi/config-long.rasi)
            case "$action" in
                "Copy")
                    cliphist decode <<< "$result" | wl-copy
                    exit
                    ;;
                "Delete")
                    cliphist delete <<< "$result"
                    ;;
                "Delete All")
                    cliphist wipe
                    ;;
                "Exit")
                    exit
                    ;;
            esac
            ;;
        10)
            cliphist delete <<< "$result"
            ;;
    esac
done
